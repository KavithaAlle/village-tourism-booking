# TourismManagementSystem
   A web version of tourism management.This is a new version of tourism managemnet.I had a travel last week with my girlfriend to DanDong.I am starting to do the web version now(2018-7-13 02:50),let me make this become a 66 days memorial.  
   The old cli version is [CliVersion](https://github.com/EugeneYilia/TourismManagement)

package com.EugeneStudio.core;

public class Route {
    private String ways;
    private int distance;

    public Route() {
    }

    public Route(String ways, int distance) {
        this.ways = ways;
        this.distance = distance;
    }
}

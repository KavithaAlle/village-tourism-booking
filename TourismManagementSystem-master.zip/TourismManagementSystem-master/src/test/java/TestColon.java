public class TestColon {
    public static void main(String[] args) {

    }

    public void a() {
        this.b();
    }

    public void b() {

    }
}

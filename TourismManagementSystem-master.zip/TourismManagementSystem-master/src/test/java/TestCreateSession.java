import io.vertx.core.Vertx;
import io.vertx.ext.web.sstore.LocalSessionStore;
import io.vertx.ext.web.sstore.SessionStore;

public class TestCreateSession {//Ignore this
    public static void main(String[] args) {
        //Vertx vertx = Vertx.vertx();
        // Create a local session store specifying the local shared map name to use and
        // setting the reaper interval for expired sessions to 10 seconds
        //SessionStore store3 = LocalSessionStore.create(vertx, "myapp3.sessionmap", 10000);
        //store3.put();
    }
}
